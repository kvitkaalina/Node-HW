const { logMessage } = require('./logger'); // Импортируем логгер

logMessage("Первое сообщение");
logMessage("Второе сообщение");
logMessage("Третье сообщение");

console.log("Все сообщения записаны в log.txt");